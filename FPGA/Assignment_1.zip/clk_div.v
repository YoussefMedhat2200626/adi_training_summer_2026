`timescale 1ns / 1ps

module clk_div(
    input clk_in,
    input rst_n,
    output reg clk_out
);
    // Mod 4,000,000 counter to toggle every 4*10^6 cycles (yields 1 Hz from 8 MHz)
    reg [21:0] count;
    
    always @(posedge clk_in or negedge rst_n) begin
        if (!rst_n) begin
            count <= 0;
            clk_out <= 0;
        end else if (count == 3_999_999) begin
            count <= 0;
            clk_out <= ~clk_out;
        end else begin
            count <= count + 1;
        end
    end
endmodule
