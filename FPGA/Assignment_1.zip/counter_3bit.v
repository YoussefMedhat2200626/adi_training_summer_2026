`timescale 1ns / 1ps

module counter_3bit(
    input clk,
    input rst_n,
    output reg [2:0] cnt
);
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cnt <= 3'b000;
        end else begin
            cnt <= cnt + 1;
        end
    end
endmodule
