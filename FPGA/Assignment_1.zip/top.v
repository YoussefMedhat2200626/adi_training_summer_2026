`timescale 1ns / 1ps

module top(
    input clk_in, // 100 MHz from board
    input rst_n,
    output [2:0] led_cnt
);
    wire clk_8m;
    wire clk_1hz;
    wire pll_locked;
    
    clk_wiz_0 u_pll (
        .clk_in1(clk_in),
        .resetn(rst_n),
        .clk_out1(clk_8m),
        .locked(pll_locked)
    );

    clk_div u_div (
        .clk_in(clk_8m),
        .rst_n(pll_locked),
        .clk_out(clk_1hz)
    );

    counter_3bit u_cnt (
        .clk(clk_1hz),
        .rst_n(pll_locked),
        .cnt(led_cnt)
    );
endmodule
