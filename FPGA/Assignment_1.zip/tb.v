`timescale 1ns / 1ps

module tb_top();

    reg clk;
    reg rst_n;
    wire [2:0] led_cnt;

    top uut (
        .clk_in(clk),
        .rst_n(rst_n),
        .led_cnt(led_cnt)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 0;
        rst_n = 0;

        #10;
        
        rst_n = 1;
        
        #200000; // Run simulation for 20 seconds
        $stop;
    end

endmodule