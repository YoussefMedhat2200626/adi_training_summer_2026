# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "")
  file(REMOVE_RECURSE
  "E:\\Analog_Devices_Internship\\Assignments\\session_5_FPGA_labs\\lab_3\\vitis_ws\\zynq_platform\\ps7_cortexa9_0\\standalone_ps7_cortexa9_0\\bsp\\include\\sleep.h"
  "E:\\Analog_Devices_Internship\\Assignments\\session_5_FPGA_labs\\lab_3\\vitis_ws\\zynq_platform\\ps7_cortexa9_0\\standalone_ps7_cortexa9_0\\bsp\\include\\xiltimer.h"
  "E:\\Analog_Devices_Internship\\Assignments\\session_5_FPGA_labs\\lab_3\\vitis_ws\\zynq_platform\\ps7_cortexa9_0\\standalone_ps7_cortexa9_0\\bsp\\include\\xtimer_config.h"
  "E:\\Analog_Devices_Internship\\Assignments\\session_5_FPGA_labs\\lab_3\\vitis_ws\\zynq_platform\\ps7_cortexa9_0\\standalone_ps7_cortexa9_0\\bsp\\lib\\libxiltimer.a"
  )
endif()
