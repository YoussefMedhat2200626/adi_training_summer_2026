/******************************************************************************
* Copyright (C) 2023 Advanced Micro Devices, Inc. All Rights Reserved.
* SPDX-License-Identifier: MIT
******************************************************************************/
/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xgpio.h"
#include "xparameters.h"

int main()
{
    init_platform();                                     // from "platform.h"

    XGpio input, output;
    int a;
    int y;

    XGpio_Initialize(&input, XPAR_AXI_GPIO_0_BASEADDR);    // from "xgpio.h"
                                                            // the input to the inverter
                                                            // output from the inverter
                                                            // set the input address
    XGpio_Initialize(&output, XPAR_AXI_GPIO_1_BASEADDR);   // set the output address
    XGpio_SetDataDirection(&input, 1, 1);                // 1: channel 1 in the AXI GPIO, 1: is i/p
    XGpio_SetDataDirection(&output, 1, 0);                 // 1: channel 1 in the AXI GPIO, 0: is o/p

    while (1) {
        a = XGpio_DiscreteRead(&input, 1);                 // read the input value and set it in "a"
        y = ~a;                                            // invert "a" and set it in "y"
        XGpio_DiscreteWrite(&output, 1, y);                // set the output to "y"
    }

    cleanup_platform();                                    // from "platform.h"
    return 0;
}