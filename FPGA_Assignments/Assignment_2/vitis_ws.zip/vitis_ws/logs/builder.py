# 2026-07-28T04:06:05.335533900
import vitis

client = vitis.create_client()
client.set_workspace(path="E:/Analog_Devices_Internship/Assignments/session_5_FPGA_Assignments/Assignment_2/vitis_ws")

comp = client.get_component(name="inverter_logic")
comp.build()

vitis.dispose()

