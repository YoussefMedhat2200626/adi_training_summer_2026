# 2026-07-27T22:57:02.869457100
import vitis

client = vitis.create_client()
client.set_workspace(path="E:/Analog_Devices_Internship/Assignments/session_5_FPGA_labs/lab_3/vitis_ws")

platform = client.create_platform_component(name = "zynq_platform",hw_design = "E:/Analog_Devices_Internship/Assignments/session_5_FPGA_labs/lab_3/FPGA_lab_3/nor_soc_wrapper.xsa",os = "standalone",cpu = "ps7_cortexa9_0",domain_name = "standalone_ps7_cortexa9_0")

comp = client.create_app_component(name="inverter_logic",platform = "E:/Analog_Devices_Internship/Assignments/session_5_FPGA_labs/lab_3/vitis_ws/zynq_platform/export/zynq_platform/zynq_platform.xpfm",domain = "standalone_ps7_cortexa9_0",template = "hello_world")

platform = client.get_component(name="zynq_platform")
status = platform.build()

status = platform.build()

comp = client.get_component(name="inverter_logic")
comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = comp.clean()

status = platform.build()

status = platform.build()

comp.build()

vitis.dispose()

