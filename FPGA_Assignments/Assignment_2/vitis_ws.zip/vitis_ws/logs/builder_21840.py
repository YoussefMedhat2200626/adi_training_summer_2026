# 2026-07-28T03:11:56.536331700
import vitis

client = vitis.create_client()
client.set_workspace(path="E:/Analog_Devices_Internship/Assignments/session_5_FPGA_labs/lab_3/vitis_ws")

platform = client.get_component(name="zynq_platform")
status = platform.build()

comp = client.get_component(name="inverter_logic")
comp.build()

vitis.dispose()

