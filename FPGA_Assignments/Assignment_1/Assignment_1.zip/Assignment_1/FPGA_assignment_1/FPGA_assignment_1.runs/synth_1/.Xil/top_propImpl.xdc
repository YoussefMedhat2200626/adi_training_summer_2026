set_property SRC_FILE_INFO {cfile:E:/Analog_Devices_Internship/Assignments/session_5_FPGA_Assignments/Assignment_1/Zedboard-Master.xdc rfile:../../../../Zedboard-Master.xdc id:1} [current_design]
set_property src_info {type:XDC file:1 line:82 export:INPUT save:INPUT read:READ} [current_design]
set_property PACKAGE_PIN Y9 [get_ports {clk}];  # "GCLK"
set_property src_info {type:XDC file:1 line:175 export:INPUT save:INPUT read:READ} [current_design]
set_property PACKAGE_PIN T22 [get_ports {counter[0]}];  # "LD0"
set_property src_info {type:XDC file:1 line:176 export:INPUT save:INPUT read:READ} [current_design]
set_property PACKAGE_PIN T21 [get_ports {counter[1]}];  # "LD1"
set_property src_info {type:XDC file:1 line:177 export:INPUT save:INPUT read:READ} [current_design]
set_property PACKAGE_PIN U22 [get_ports {counter[2]}];  # "LD2"
set_property src_info {type:XDC file:1 line:237 export:INPUT save:INPUT read:READ} [current_design]
set_property PACKAGE_PIN F22 [get_ports {rst_n}];  # "SW0"
set_property src_info {type:XDC file:1 line:371 export:INPUT save:INPUT read:READ} [current_design]
set_false_path -from rst_n -to counter_reg[0]/CLR
set_property src_info {type:XDC file:1 line:372 export:INPUT save:INPUT read:READ} [current_design]
set_false_path -from rst_n -to counter_reg[1]/CLR
set_property src_info {type:XDC file:1 line:373 export:INPUT save:INPUT read:READ} [current_design]
set_false_path -from rst_n -to counter_reg[2]/CLR
set_property src_info {type:XDC file:1 line:375 export:INPUT save:INPUT read:READ} [current_design]
set_false_path -from counter_reg[0]/C -to counter[0]
set_property src_info {type:XDC file:1 line:376 export:INPUT save:INPUT read:READ} [current_design]
set_false_path -from counter_reg[1]/C -to counter[1]
set_property src_info {type:XDC file:1 line:377 export:INPUT save:INPUT read:READ} [current_design]
set_false_path -from counter_reg[2]/C -to counter[2]
set_property src_info {type:XDC file:1 line:380 export:INPUT save:INPUT read:READ} [current_design]
set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 33]];
set_property src_info {type:XDC file:1 line:390 export:INPUT save:INPUT read:READ} [current_design]
set_property IOSTANDARD LVCMOS18 [get_ports -of_objects [get_iobanks 35]];
set_property src_info {type:XDC file:1 line:393 export:INPUT save:INPUT read:READ} [current_design]
set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 13]];
