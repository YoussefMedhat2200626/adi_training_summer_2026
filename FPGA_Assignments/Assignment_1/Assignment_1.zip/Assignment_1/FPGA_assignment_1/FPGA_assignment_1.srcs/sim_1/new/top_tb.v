`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/26/2026 05:23:23 AM
// Design Name: 
// Module Name: top_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module top_tb();
    reg clk;
    reg rst_n;
    wire [2 :0] counter;
    
    top dut(
       .clk(clk),
       .rst_n(rst_n),
       .counter(counter)
    );
    
    initial begin
        clk = 0;
        forever #5 clk = ~ clk;
    end
    
    initial begin
        rst_n = 1'b0;
        #50;
        rst_n = 1'b1;
        
        #2000000;
        $finish;
    end
    
    initial begin
        $display("Time\tReset\tCounter");
        $monitor("%0t\t%b\t%h", $time, rst_n, counter);
    end
endmodule
