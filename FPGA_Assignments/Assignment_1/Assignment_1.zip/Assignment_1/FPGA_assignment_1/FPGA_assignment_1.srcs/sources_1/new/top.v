// Company: 
// Engineer: 
// 
// Create Date: 07/26/2026 04:46:42 AM
// Design Name: 
// Module Name: top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module top(clk, rst_n, counter);
    input clk;
    input rst_n;
    output [2 : 0] counter;
    
    wire pll_clk;
    wire pll_rst;
    wire div_clk;
    
    clk_wiz_0 U_pll
   (
    // Clock out ports
    .clk_out1(pll_clk),     // output clk_out1
    // Status and control signals
    .resetn(rst_n), // input resetn
    .locked(pll_rst),       // output locked
   // Clock in ports
    .clk_in1(clk)      // input clk_in1
);

    clock_divider clk_div (.clk_in(pll_clk),
                  .rst_n(pll_rst),
                  .clk_out(div_clk)
    );
    
    counter count_inst (.clk(div_clk),
            .rst_n(pll_rst),
            .counter(counter)
    );
endmodule
