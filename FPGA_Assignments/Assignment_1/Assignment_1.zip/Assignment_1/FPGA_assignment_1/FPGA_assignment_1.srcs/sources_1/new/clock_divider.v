// Company: 
// Engineer: 
// 
// Create Date: 07/26/2026 04:32:44 AM
// Design Name: 
// Module Name: clock_divider
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module clock_divider(clk_in, rst_n, clk_out);
    input clk_in;
    input rst_n;
    output reg clk_out;
    
    reg [21 : 0] counter;
    
    always @ (posedge clk_in or negedge rst_n) begin
        if (! rst_n) begin
            counter <= 0;
            clk_out <= 0;
        end
        else begin
            if (counter == 3999999) begin
                counter <= 0;
                clk_out <= ~ clk_out;
            end
            else begin
                counter <= counter + 1'b1;
            end
        end
    end 
endmodule
