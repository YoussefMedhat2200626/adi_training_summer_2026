`timescale 1ns/1ps

module top_tb;

    reg clk;
    reg rst_n;
    wire [2:0] counter;

    top dut (
        .clk    (clk),
        .rst_n  (rst_n),
        .counter(counter)
    );

    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        $display("Time\tRST_N\tCounter");
        $monitor("%0t\t%b\t%d", $time, rst_n, counter);

        rst_n = 0;
        #12;
        rst_n = 1;

        #200;

        rst_n = 0;
        #7;
        rst_n = 1;

        #200;

        $display("Simulation finished at time %0t", $time);
        $stop;
    end

    initial begin
        $dumpfile("counter_tb.vcd");
        $dumpvars(0, top_tb);
    end

endmodule