module top
(
    input        clk,
    input        rst_n,
    output [2:0] counter
);

wire clk_8;
wire clk_1;
wire lock_counter;

clk_wiz_0 u_pll
(
    // Clock out ports
    .clk_out1(clk_8),     // output clk_out1
    // Status and control signals
    .resetn(rst_n),             // input resetn
    .locked(lock_counter),      // output locked

    // Clock in ports
    .clk_in1(clk)               // input clk_in1
);

counter u_count
(
    .clk(clk_1),
    .rst_n(lock_counter),
    .counter(counter)
);

clock_divider u_divider
(
    .clk(clk_8),
    .rst_n(lock_counter),
    .clk_1(clk_1)
);

endmodule