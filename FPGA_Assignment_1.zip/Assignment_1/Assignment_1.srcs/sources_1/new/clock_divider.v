module clock_divider
(
    input  clk,
    input  rst_n,
    output reg clk_1
);

reg [22:0] count;

always @(posedge clk or negedge rst_n)
begin
    if(!rst_n)
    begin
        count   <= 23'd0;
        clk_1 <= 1'b0;
    end
    else
    begin
        if(count == 23'd3999999)
        begin
            count   <= 23'd0;
            clk_1 <= ~clk_1;
        end
        else
            count <= count + 1'b1;
    end
end

endmodule