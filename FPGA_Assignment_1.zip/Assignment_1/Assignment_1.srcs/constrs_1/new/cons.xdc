# Clock
set_property PACKAGE_PIN Y9 [get_ports clk]
create_clock -name clk -period 10 [get_ports clk]

create_generated_clock -name clk_1Hz \
    -source [get_pins u_pll/clk_out1] \
    -divide_by 8000000 \
    [get_pins u_divider/clk_1_reg/Q]
    
set_false_path -from [get_ports rst_n] -to [get_pins u_count/counter_reg[0]/CLR]
set_false_path -from [get_ports rst_n] -to [get_pins u_count/counter_reg[1]/CLR]
set_false_path -from [get_ports rst_n] -to [get_pins u_count/counter_reg[2]/CLR]
    
set_false_path -from [get_ports rst_n] -to [get_pins u_count/counter_reg[0]/CLR]
set_false_path -from [get_ports rst_n] -to [get_pins u_count/counter_reg[1]/CLR]
set_false_path -from [get_ports rst_n] -to [get_pins u_count/counter_reg[2]/CLR]
# LEDs
set_property PACKAGE_PIN T22 [get_ports {counter[0]}]
set_property PACKAGE_PIN T21 [get_ports {counter[1]}]
set_property PACKAGE_PIN U22 [get_ports {counter[2]}]

# Reset
set_property PACKAGE_PIN F22 [get_ports rst_n]

# I/O Standards
set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 33]]
set_property IOSTANDARD LVCMOS18 [get_ports -of_objects [get_iobanks 35]]
set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 13]]