# Clock
set_property PACKAGE_PIN Y9 [get_ports clk]
create_clock -name clk -period 10 [get_ports clk]
    
set_false_path -from rst_n -to counter_reg[0]/CLR
set_false_path -from rst_n -to counter_reg[1]/CLR
set_false_path -from rst_n -to counter_reg[2]/CLR
set_false_path -from rst_n -to counter_reg[3]/CLR

set_false_path -from counter_reg[0]/C -to counter[0]
set_false_path -from counter_reg[1]/C -to counter[1]
set_false_path -from counter_reg[2]/C -to counter[2]
set_false_path -from counter_reg[3]/C -to counter[3]

# LEDs
set_property PACKAGE_PIN T22 [get_ports {counter[0]}]
set_property PACKAGE_PIN T21 [get_ports {counter[1]}]
set_property PACKAGE_PIN U22 [get_ports {counter[2]}]

# Reset
set_property PACKAGE_PIN F22 [get_ports rst_n]

# I/O Standards
set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 33]]
set_property IOSTANDARD LVCMOS18 [get_ports -of_objects [get_iobanks 35]]
set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 13]]