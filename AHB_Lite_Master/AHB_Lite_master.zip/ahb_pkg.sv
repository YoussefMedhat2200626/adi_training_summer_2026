package ahb_pkg;

    typedef enum logic [1:0] {
        IDLE   = 2'b00,
        BUSY   = 2'b01,
        NONSEQ = 2'b10,
        SEQ    = 2'b11
    } htrans_t;

    typedef enum logic [2:0] {
        SINGLE = 3'b000,
        INCR   = 3'b001,
        WRAP4  = 3'b010,
        INCR4  = 3'b011,
        WRAP8  = 3'b100,
        INCR8  = 3'b101,
        WRAP16 = 3'b110,
        INCR16 = 3'b111
    } hburst_t;

    typedef enum logic [2:0] {
        BYTE     = 3'b000,
        HALFWORD = 3'b001,
        WORD     = 3'b010,
        DWORD    = 3'b011
    } hsize_t;

    typedef struct packed {
        logic [31:0] addr;
        logic [31:0] wdata;
        logic        write;
        hsize_t      size;
        hburst_t     burst;
        htrans_t     trans;

    } transaction_t;


endpackage

