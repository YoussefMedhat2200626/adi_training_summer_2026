onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /test_ahb/HADDR
add wave -noupdate /test_ahb/HTRANS
add wave -noupdate /test_ahb/HBURST
add wave -noupdate /test_ahb/HCLK
add wave -noupdate /test_ahb/HRDATA
add wave -noupdate /test_ahb/HREADY
add wave -noupdate /test_ahb/HRESETn
add wave -noupdate /test_ahb/HRESP
add wave -noupdate /test_ahb/HSIZE
add wave -noupdate /test_ahb/HWDATA
add wave -noupdate /test_ahb/HWRITE
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {110092 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ns
update
WaveRestoreZoom {38058 ps} {124696 ps}
