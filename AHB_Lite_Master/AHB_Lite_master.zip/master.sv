import ahb_pkg::*;
module master (

    input  logic            HCLK,
    input  logic            HRESETn,
    input  logic [31:0]     HRDATA,
    input  logic            HREADY,
    input  logic            HRESP,
    input  transaction_t    tr,
    output logic [31:0]     HADDR,
    output logic            HWRITE,
    output hsize_t          HSIZE,
    output hburst_t         HBURST,
    output logic [3:0]      HPROT,
    output htrans_t         HTRANS,
    output logic            HMASTLOCK,
    output logic [31:0]     HWDATA

);

typedef enum logic [1:0] {
    s_IDLE,
    s_BUSY,
    s_NON_SEQ,
    s_SEQ
} state_t;

state_t current_state, next_state;
logic [31:0] HWDATA_reg;

assign HPROT = 'b0011;
assign HMASTLOCK = 0;

always @(posedge HCLK or negedge HRESETn) begin
    if(!HRESETn)
        current_state <= s_IDLE;
    else
        current_state <= next_state;
end

always @(*) begin
    case(current_state)
        s_IDLE: begin
            if(tr.trans == NONSEQ)
                next_state = s_NON_SEQ;
            else 
                next_state = s_IDLE;
        end

        s_BUSY: begin
            if (tr.trans == SEQ)
                next_state = s_SEQ; 
            else if (tr.trans == NONSEQ) 
                next_state = s_NON_SEQ; 
            else if (tr.trans == IDLE)
                next_state = s_IDLE; 
            else
                next_state = s_BUSY; 
            end

        s_NON_SEQ: begin
            if (!HREADY) 
                next_state = s_BUSY;
            else if(tr.trans == SEQ)
                next_state = s_SEQ;

            else if(tr.trans == IDLE)
                next_state = s_IDLE;

            else if(tr.trans == NONSEQ && HBURST == SINGLE)
                next_state = s_NON_SEQ;
            else
                next_state = s_SEQ;

        end
        s_SEQ: begin
            if (!HREADY) 
                next_state = s_BUSY;
            else if(tr.trans == IDLE)
                next_state = s_IDLE;

            else if(tr.trans == NONSEQ)
                next_state = s_NON_SEQ;
            else
                next_state = s_SEQ;
        end
        default: next_state = s_IDLE;
    endcase

end

always @(*) begin

    if(!HRESETn) begin
        HADDR = 'b0;
        HWRITE = 0;
        HWDATA_reg = '0;
        HSIZE = BYTE;
        HBURST = SINGLE;

    end
    else begin

        if(current_state == s_IDLE) begin
                HADDR = 'b0; 
                HWDATA_reg = 'b0; 
                HWRITE = 'b0; 
                HSIZE = BYTE; 
                HTRANS = IDLE;

        end

        else if(current_state == s_BUSY ) begin
                HADDR = HADDR; 
                HWDATA_reg = HWDATA_reg; 
                HWRITE = HWRITE; 
                HSIZE = HSIZE; 
                HBURST = HBURST; 
                HTRANS = BUSY;
        end
        else if(current_state == s_NON_SEQ) begin
                HADDR = tr.addr; 
                HWDATA_reg = tr.wdata; 
                HWRITE = tr.write; 
                HSIZE = tr.size; 
                HBURST = tr.burst; 
                HTRANS = NONSEQ;
        end        
        else if (current_state == s_SEQ) begin
            HTRANS = SEQ;
                if (tr.burst == INCR && !tr.size) begin 
                    HADDR = HADDR + 1 ; 
                    HWDATA_reg = {24'h000000, tr.wdata[7:0]}; 
                    HWRITE = tr.write; 
                    HSIZE = tr.size;  
                    HBURST = tr.burst;  
                end          
                else if (tr.burst == INCR && tr.size == HALFWORD) begin
                    HWDATA_reg = {16'h0000, tr.wdata[15:0]}; 
                    HWRITE = tr.write; 
                    HSIZE = tr.size; 
                    HBURST = tr.burst;    
                end
                else if (tr.burst == INCR && tr.size == WORD) begin 
                    HADDR = HADDR + 4 ; 
                    HWDATA_reg = tr.wdata; 
                    HWRITE = tr.write; 
                    HSIZE = tr.size;  
                    HBURST = tr.burst;    
                end
                else if (!tr.burst) begin 
                    HADDR = tr.addr; 
                    HWDATA_reg = tr.wdata; 
                    HWRITE = tr.write; 
                    HSIZE = tr.size; 
                    HBURST = tr.burst;    
                end
            end
        end
    end


//for data phase
    always @(posedge HCLK) begin
        if (HREADY) HWDATA <= HWDATA_reg;
    end

endmodule 

