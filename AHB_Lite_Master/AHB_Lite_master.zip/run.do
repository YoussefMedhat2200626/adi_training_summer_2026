vlib work
vlog ahb_pkg.sv master.sv test_ahb.sv
vsim -voptargs=+acc work.test_ahb
do wave.do
run -all
