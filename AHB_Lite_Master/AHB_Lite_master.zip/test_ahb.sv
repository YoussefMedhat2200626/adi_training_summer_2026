`timescale 1ns/1ps

import ahb_pkg::*;

module test_ahb;

logic HCLK;
logic HRESETn;
logic [31:0] HRDATA;
logic HREADY;
logic HRESP;
transaction_t tr;
logic [31:0] HADDR;
logic HWRITE;
hsize_t HSIZE;
hburst_t HBURST;
logic [3:0] HPROT;
htrans_t HTRANS;
logic HMASTLOCK;
logic [31:0] HWDATA;

master DUT (.* );

initial begin
    HCLK = 0;
    forever #5 HCLK = ~HCLK;
end

task reset;
begin
    HRESETn = 0;

    HREADY = 1;
    HRESP  = 0;
    HRDATA = 32'h0;
    tr = '0;
    repeat(3) @(posedge HCLK);
    HRESETn = 1;
    @(posedge HCLK);
end
endtask

task automatic send_transaction( input htrans_t trans,
    input hburst_t burst,
    input hsize_t size,
    input logic write,
    input logic [31:0] addr,
    input logic [31:0] data);

begin

    tr.trans = trans;
    tr.burst = burst;
    tr.size  = size;
    tr.write = write;
    tr.addr  = addr;
    tr.wdata = data;

    @(posedge HCLK);

    $display("--------------------------------");
    $display("Time    = %0t",$time);
    $display("State   = %0d",DUT.current_state);
    $display("HTRANS  = %0d",HTRANS);
    $display("HADDR   = %h",HADDR);
    $display("HWDATA  = %h",HWDATA);
    $display("HBURST  = %0d",HBURST);

end

endtask

initial begin

    reset();
    // IDLE
    send_transaction(IDLE,SINGLE,BYTE,0,32'h0,32'h0);

    // SINGLE WRITE
    send_transaction(
        NONSEQ,
        SINGLE,
        WORD,
        1,
        32'h1000_0000,
        32'hAAAA5555
    );
    #20

    // INCR BYTE
    send_transaction(
        NONSEQ,
        INCR,
        BYTE,
        1,
        32'h2000_0000,
        32'h11
    );
    #20

    // SINGLE HALFWORD

    send_transaction(
        NONSEQ,
        SINGLE,
        HALFWORD,
        1,
        32'h3000_0000,
        32'h1234
    );

    #10
    send_transaction(
        SEQ,
        INCR,
        WORD,
        1,
        32'h7000_0000,
        32'hABCD1234
    );
    #10
        HREADY = 0;

    repeat(2)
        @(posedge HCLK);

    HREADY = 1;







    #20;

    $stop;

end

endmodule