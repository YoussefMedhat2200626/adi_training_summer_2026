`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/26/2026 09:25:36 PM
// Design Name: 
// Module Name: tb_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

`timescale 1ns/1ps

module tb_top;

reg clk;
reg rst_n;
wire [2:0] counter;

// DUT
top dut (
    .clk(clk),
    .rst_n(rst_n),
    .counter(counter)
);

// 100 MHz clock (10 ns period)
initial begin
    clk = 1'b0;
    forever #5 clk = ~clk;
end

// Reset sequence
initial begin
    rst_n = 1'b0;

    #100;
    rst_n = 1'b1;

    #1000000;
    $stop;
end

// Monitor signals
initial begin
    $monitor("Time=%0t rst_n=%b counter=%d", $time, rst_n, counter);
end

endmodule