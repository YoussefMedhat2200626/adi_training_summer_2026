`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/26/2026 10:55:39 PM
// Design Name: 
// Module Name: clk_divider
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module clk_divider(
    input clk,
    input rst_n,
    output reg clk_out
);

//parameter DIVISOR = 4;  //divisor used in simulation
parameter DIVISOR = 4000000;

reg [22:0] count;

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        count   <= 0;
        clk_out <= 1'b0;
    end else begin
        if (count == DIVISOR - 1) begin
            count   <= 0;
            clk_out <= ~clk_out;
        end else begin
            count <= count + 1'b1;
        end
    end
end

endmodule
