`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/26/2026 09:02:25 PM
// Design Name: 
// Module Name: top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module top(
    input clk,
    input rst_n,
    output [2:0] counter
);
 
wire clk_counter;   // 8 MHz from PLL
wire lock_counter;  // PLL locked
wire clk_1hz;       // 1 Hz from divider
 
counter u_count(
    .clk(clk_1hz),
    .rst_n(lock_counter),
    .counter(counter)
);
 
clk_divider u_div(
    .clk(clk_counter),
    .rst_n(lock_counter),
    .clk_out(clk_1hz)
);
 
clk_wiz_0 u_pll
    (
    .clk_out1(clk_counter),
    .resetn(rst_n),
    .locked(lock_counter),
    .clk_in1(clk));
 
endmodule