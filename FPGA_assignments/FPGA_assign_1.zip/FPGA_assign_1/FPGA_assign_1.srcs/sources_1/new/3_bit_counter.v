module counter_3bit (
    input  wire       clk,     
    input  wire       rst_n,    
    input  wire       tick,     
    output reg [2:0]  led_out   
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            led_out <= 3'b000;
        else if (tick)
            led_out <= led_out + 1'b1;  
    end

endmodule