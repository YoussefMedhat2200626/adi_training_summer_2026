`timescale 1ns/1ps

module tb_top;

    reg        osc_clk;
    reg        btn_rst;
    wire [2:0] led;
    
    top uut (
        .osc_clk (osc_clk),
        .btn_rst (btn_rst),
        .led     (led)
    );

    
    always #5 osc_clk = ~osc_clk;

    initial begin
        osc_clk = 0;
        btn_rst = 1;      
        #1000;
        btn_rst = 0;

        $display("Waiting for PLL lock and first counter increments...");
    end

    initial begin
        $monitor("Time=%0t ns | led=%b", $time, led);
    end

    
    initial begin
        #5_000_000_000;    
        $display("Simulation complete.");
        $stop;
    end

endmodule