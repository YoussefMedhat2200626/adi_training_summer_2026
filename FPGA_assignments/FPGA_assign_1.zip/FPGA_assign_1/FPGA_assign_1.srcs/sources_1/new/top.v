module top (
    input  wire       osc_clk,  
    input  wire       btn_rst,   
    output wire [2:0] led
);

    wire clk_8mhz;
    wire pll_locked;
    wire rst_n = pll_locked & ~btn_rst;  

    wire tick;

    clk_wiz_0 u_pll ( .clk_in1  (osc_clk), .clk_out1 (clk_8mhz), .reset(btn_rst), .locked   (pll_locked));

    clock_divider #( .CLK_FREQ_HZ (8_000_000), .TARGET_HZ   (1)) u_div ( .clk   (clk_8mhz), .rst_n (rst_n), .tick  (tick));

    counter_3bit u_cnt ( .clk     (clk_8mhz), .rst_n   (rst_n), .tick    (tick), .led_out (led));

endmodule