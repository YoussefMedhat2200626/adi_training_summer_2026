module clock_divider(
    input  wire clk,        
    input  wire rst_n,       
    output reg  tick         
);
    
    parameter CLK_FREQ_HZ = 8000000;
    parameter TARGET_HZ   = 1;
    localparam  MAX_COUNT = (CLK_FREQ_HZ / TARGET_HZ) - 1; 

    reg [22:0] count; 

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            count <= 0;
            tick  <= 1'b0;
        end else if (count == MAX_COUNT) begin
            count <= 0;
            tick  <= 1'b1;      
        end else begin
            count <= count + 1'b1;
            tick  <= 1'b0;
        end
    end

endmodule