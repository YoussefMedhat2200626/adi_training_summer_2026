# ----------------------------------------------------------------------------
# Clock Source - Bank 13 (100 MHz oscillator -> PLL clk_in1)
# ----------------------------------------------------------------------------
set_property PACKAGE_PIN Y9 [get_ports {osc_clk}];        
set_property IOSTANDARD LVCMOS33 [get_ports {osc_clk}];
create_clock -name osc_clk -period 10.000 [get_ports {osc_clk}];   

# ----------------------------------------------------------------------------
# User DIP Switch - Bank 35 (reset input)
# ----------------------------------------------------------------------------
set_property PACKAGE_PIN F22 [get_ports {btn_rst}];      # "SW0"

# ----------------------------------------------------------------------------
# User LEDs - Bank 33 (3-bit counter output)
# ----------------------------------------------------------------------------
set_property PACKAGE_PIN T22 [get_ports {led[0]}];       # "LD0"
set_property PACKAGE_PIN T21 [get_ports {led[1]}];       # "LD1"
set_property PACKAGE_PIN U22 [get_ports {led[2]}];       # "LD2"

# ----------------------------------------------------------------------------
# Timing exceptions
# ----------------------------------------------------------------------------
set_false_path -to [get_ports {led[*]}]
set_false_path -from [get_ports {btn_rst}]

# ----------------------------------------------------------------------------
# IOSTANDARD Constraints (bank-wide, per Zedboard-Master.xdc)
# ----------------------------------------------------------------------------
set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 33]];  # LEDs - fixed 3.3V

# Bank 34 unused in this design - comment out entirely to avoid critical warning
# set_property IOSTANDARD LVCMOS18 [get_ports -of_objects [get_iobanks 34]];

set_property IOSTANDARD LVCMOS18 [get_ports -of_objects [get_iobanks 35]];  # reset switch

set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 13]]; # clock input - fixed 3.3V