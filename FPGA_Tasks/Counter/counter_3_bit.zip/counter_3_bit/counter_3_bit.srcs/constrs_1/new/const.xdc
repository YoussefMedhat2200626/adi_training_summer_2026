# ----------------------------------------------------------------------------
# User LEDs - Bank 33
# ----------------------------------------------------------------------------
set_property PACKAGE_PIN T22 [get_ports {counter[0]}]
set_property PACKAGE_PIN T21 [get_ports {counter[1]}]
set_property PACKAGE_PIN U22 [get_ports {counter[2]}]
## ----------------------------------------------------------------------------
## User DIP Switches - Bank 35
## ----------------------------------------------------------------------------
set_property PACKAGE_PIN F22 [get_ports rst_n]

# ----------------------------------------------------------------------------
# Clock Source - Bank 13
# ----------------------------------------------------------------------------
set_property PACKAGE_PIN Y9 [get_ports clk]
#--------------------------------------------------------------
# Timing cons
#--------------------------------------------------------------
create_clock -name clk -period 10 [get_ports clk]
#clock from PLL output
create_generated_clock -name counter_clk \
    -source clk \
    -divide_by [expr 100/8] \
    pll/clk_out1

set_false_path -from rst_n -to counter_reg[0]/CLR
set_false_path -from rst_n -to counter_reg[1]/CLR
set_false_path -from rst_n -to counter_reg[2]/CLR

set_false_path -from counter_reg[0]/C -to counter[0]
set_false_path -from counter_reg[1]/C -to counter[1]
set_false_path -from counter_reg[2]/C -to counter[2]

# Note that the bank voltage for IO Bank 33 is fixed to 3.3V on ZedBoard.
set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 33]]

# Set the bank voltage for IO Bank 34 to 1.8V by default.
# set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 34]];
# set_property IOSTANDARD LVCMOS25 [get_ports -of_objects [get_iobanks 34]];
#set_property IOSTANDARD LVCMOS18 [get_ports -of_objects [get_iobanks 34]];

# Set the bank voltage for IO Bank 35 to 1.8V by default.
# set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 35]];
# set_property IOSTANDARD LVCMOS25 [get_ports -of_objects [get_iobanks 35]];
set_property IOSTANDARD LVCMOS18 [get_ports -of_objects [get_iobanks 35]]

# Note that the bank voltage for IO Bank 13 is fixed to 3.3V on ZedBoard.
set_property IOSTANDARD LVCMOS33 [get_ports -of_objects [get_iobanks 13]]

