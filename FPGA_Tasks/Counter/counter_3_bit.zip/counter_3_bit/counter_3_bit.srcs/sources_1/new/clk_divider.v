module clk_divider (
    input clk_in,
    input rst_n,
    output reg clk_out
);
    //divide from 8mhz to 1hz
    reg [21:0] counter; // 22 bits to count 4000000
    always @(posedge clk_in or negedge rst_n) begin
        if (!rst_n) begin
            counter <= 0;
            clk_out <= 0;
        end else begin
            if (counter == 3_999_999) begin 
                counter <= 0;
                clk_out <= ~clk_out;
            end else begin
                counter <= counter + 1;
            end
        end
    end
endmodule

