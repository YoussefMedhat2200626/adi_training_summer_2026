module counter_top(
input clk,
input rst_n,
output [2:0] counter);

wire clk_pll,locked_pll;
wire clk_div;


//----------- Begin Cut here for INSTANTIATION Template ---// INST_TAG

  clk_wiz_0 pll
   (
    // Clock out ports
    .clk_out1(clk_pll),     // output clk_out1
    // Status and control signals
    .resetn(rst_n), // input resetn
    .locked(locked_pll),       // output locked
   // Clock in ports
    .clk_in1(clk));      // input clk_in1
// INST_TAG_END ------ End INSTANTIATION Template ---------

clk_divider div1(
.clk_in(clk_pll),
.clk_out(clk_div),
.rst_n(locked_pll));

counter cntr1 (
.clk(clk_div),
.rst_n(locked_pll),
.counter(counter));




endmodule
