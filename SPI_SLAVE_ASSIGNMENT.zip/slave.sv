module slave #( parameter ADDR_WIDTH = 15, DATA_WIDTH = 8)(
    input  wire                   sclk, rst_n,
    input  wire                   csb,
    input  wire                   sdi,
    input  wire [DATA_WIDTH-1:0]  rd_data,
    output wire                   sdo,
    output reg  [ADDR_WIDTH-1:0]  addr,
    output reg                    wr_en,
    output reg  [DATA_WIDTH-1:0]  wr_data
);

    localparam HEADER_BITS  = 16; 
    localparam LAST_HDR_BIT = HEADER_BITS - 1;

    typedef enum logic [1:0] {
        IDLE,
        HEADER,
        DATA
    } state_t;

    state_t state;

    reg                         rw;
    reg [4:0]  bit_cnt;
    reg [3:0]   data_counter;
    reg [DATA_WIDTH-1:0]           rx_shift;
    reg [DATA_WIDTH-1:0]           tx_shift;
    reg                            sdo_reg;

    wire sdo_oe = !csb && rw && (state == DATA);
    assign sdo = sdo_oe ? sdo_reg : 1'b0;

    always_ff @(posedge csb or negedge csb or posedge sclk or negedge rst_n) begin

        if (!rst_n) begin

            state        <= IDLE;
            rw           <= 1'b0;
            bit_cnt      <= '0;
            data_counter <= '0;
            addr         <= '0;
            rx_shift     <= '0;
            wr_en        <= 1'b0;
            wr_data      <= '0;

        end
        else begin

            wr_en <= 1'b0;

            if (csb) begin
                state        <= IDLE;
                bit_cnt      <= '0;
                data_counter <= '0;
            end
            else begin

               case (state)

                    IDLE: begin
                        state   <= HEADER;
                        bit_cnt <= '0;
                    end

           HEADER: begin

                        bit_cnt <= bit_cnt + 1'b1;

                        if (bit_cnt == 0)
                            rw <= sdi;                                
                        else
                            addr <= {addr[ADDR_WIDTH-2:0], sdi};         

                        if (bit_cnt == LAST_HDR_BIT) begin
                            // needs to sample it.
                            state        <= DATA;
                            data_counter <= '0;
                        end
                    end
              DATA: begin

                        if (!rw) begin
                            rx_shift <= {rx_shift[DATA_WIDTH-2:0], sdi};

                            if (data_counter == 'b111) begin
                                wr_data      <= {rx_shift[DATA_WIDTH-2:0], sdi};
                                wr_en        <= 1'b1;
                                addr         <= addr + 1'b1;   // burst auto-increment
                                data_counter <= '0;
                    end
                        else begin
                                data_counter <= data_counter + 1'b1;
                            end
                        end
                        else begin
                            if (data_counter == 'b111) begin
                                addr         <= addr + 1'b1;
                        data_counter <= '0;
                            end
                            else begin
                                data_counter <= data_counter + 1'b1;
                            end
                        end
                    end

                endcase

            end

        end

    end

    always_ff @(negedge sclk or posedge csb or negedge csb or negedge rst_n) begin

        if (!rst_n || csb) begin
            sdo_reg  <= 1'b0;
            tx_shift <= '0;
        end
        else if (rw && state == DATA) begin
            if (data_counter == '0) begin
                sdo_reg  <= rd_data[DATA_WIDTH-1];
                tx_shift <= {rd_data[DATA_WIDTH-2:0], 1'b0};
            end
            else begin
                sdo_reg  <= tx_shift[DATA_WIDTH-1];
                tx_shift <= {tx_shift[DATA_WIDTH-2:0], 1'b0};
            end
        end

    end

endmodule