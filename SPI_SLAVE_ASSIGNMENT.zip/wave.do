onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /spi_slave_tb/dut/u_spi_slave/rst_n
add wave -noupdate /spi_slave_tb/dut/u_spi_slave/sclk
add wave -noupdate /spi_slave_tb/dut/u_spi_slave/csb
add wave -noupdate /spi_slave_tb/dut/u_spi_slave/sdi
add wave -noupdate /spi_slave_tb/dut/u_spi_slave/sdo
add wave -noupdate -radix unsigned /spi_slave_tb/dut/u_spi_slave/addr
add wave -noupdate /spi_slave_tb/dut/u_spi_slave/rd_data
add wave -noupdate -radix binary /spi_slave_tb/dut/u_spi_slave/wr_data
add wave -noupdate /spi_slave_tb/dut/u_spi_slave/bit_cnt
add wave -noupdate /spi_slave_tb/dut/u_spi_slave/data_counter
add wave -noupdate /spi_slave_tb/dut/u_spi_slave/rw
add wave -noupdate /spi_slave_tb/dut/u_spi_slave/state
add wave -noupdate /spi_slave_tb/dut/u_spi_slave/wr_en
add wave -noupdate /spi_slave_tb/dut/u_reg_map/reg_m
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {275000 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ns
update
WaveRestoreZoom {173443 ps} {315436 ps}
