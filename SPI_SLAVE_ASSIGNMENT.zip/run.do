vlib work
vlog *.*v 
vsim -voptargs=+acc work.spi_slave_tb
do wave.do
run -all
