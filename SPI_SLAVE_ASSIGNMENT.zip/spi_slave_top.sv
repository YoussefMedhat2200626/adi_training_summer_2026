 module spi_slave_top #(parameter DATA_WIDTH = 8, ADDR = 15)(
    input  wire                   rst_n,
    input  wire                   sclk,
    input  wire                   csb,
    input  wire                   sdi,
    output wire                   sdo
);

wire [DATA_WIDTH-1:0]  rd_data, wr_data;
wire  [ADDR-1:0]      addr;  
wire                    wr_en;

reg_map #(.DATA_WIDTH(DATA_WIDTH), .ADDR_WIDTH(ADDR)) u_reg_map (
    .sclk(sclk),
    .rst_n(rst_n),
    .addr(addr),
    .wr_en(wr_en),
    .wr_data(wr_data),
    .rd_data(rd_data)
);

slave #(.DATA_WIDTH(DATA_WIDTH), .ADDR_WIDTH(ADDR)) u_spi_slave (
    .sclk(sclk),
    .rst_n(rst_n),
    .csb(csb),
    .sdi(sdi),
    .rd_data(rd_data),
    .sdo(sdo),
    .addr(addr),
    .wr_en(wr_en),
    .wr_data(wr_data)
);

endmodule