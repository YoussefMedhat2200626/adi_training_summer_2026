`timescale 1ns/1ps
module spi_slave_tb();
reg                   rst_n;
reg                   sclk;
reg                   csb;
reg                   sdi;
wire                  sdo;

localparam clk_period = 10;
spi_slave_top dut (.*);

logic sclk_en;
initial begin
    sclk = 0;
    forever begin
        if (sclk_en)
          begin
            #5;
            sclk = ~sclk;  
        end else
            @(sclk_en);  
    end
end

task reset;
    begin
        rst_n = 1'b0;
        #(clk_period);
        rst_n = 1'b1;
    end
endtask

task DATA_IN ;
 input  [23:0]  DATA ;

 integer   i;
 begin
    csb = 0;
    #clk_period;
    sclk_en = 1;

	for(i=23; i>= 0; i--)
		begin
				
		sdi <= DATA[i] ;       // data bits
                #clk_period; 
		end 
     sclk_en = 0;
    #clk_period;
     csb = 1;
	
 end
endtask

task BURST_IN ;
 input  [39:0]  DATA ;

 integer   i;
 begin
    csb = 0;
    #clk_period;
    sclk_en = 1;

	for(i=39; i>= 0; i--)
		begin
				
		sdi <= DATA[i] ;       // data bits
        #clk_period; 
		end 
     sclk_en = 0;
    #clk_period;
     csb = 1;
	
 end
endtask

initial 
begin
     sclk_en = 0;
     sdi = 0;
     csb = 1;
     reset;
     #20;
     //write operation
     DATA_IN('b0_100100101010011_00100010);
     #10;
     //read operation
     DATA_IN('b1_100100101010011_00000000);
     #10;
     //burst write operation
     BURST_IN('b0_000000000000001_11111111_01010101_11110000);

    #10;
     //burst read operation
     BURST_IN('b1_000000000000001_00000000_00000000_00000000);
     
    

    #100
  $stop;
end
    
endmodule