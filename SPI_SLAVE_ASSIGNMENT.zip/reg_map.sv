module reg_map #(parameter DATA_WIDTH = 8,ADDR_WIDTH = 15, DEPTH = 32768)(
    input wire                   sclk, rst_n,
    input wire [ADDR_WIDTH-1:0]  addr,
    input wire                   wr_en,
    input wire [DATA_WIDTH-1:0]  wr_data,
    output reg [DATA_WIDTH-1:0]  rd_data
);

reg [DATA_WIDTH-1:0] reg_m [DEPTH-1:0];

assign rd_data = (wr_en)? 'b0:reg_m[addr-1];

always @(negedge sclk or negedge rst_n) begin
    if(!rst_n)
       for (int i=0; i<DEPTH; i++) begin
          reg_m[i] <= 'b0;
       end
    else if (wr_en) begin
        reg_m [addr-1] <= wr_data;
    end
end
    
endmodule