`timescale 1ns / 1ps

module spi_wrapper (
    input  wire csb,
    input  wire clk,
    input  wire sdi,
    output wire sdo
);

    // Internal wires connecting the slave to the register map
    wire [14:0] internal_addr;
    wire        internal_wr_en;
    wire [7:0]  internal_wr_data;
    wire [7:0]  internal_rd_data;

    // Instantiate SPI Slave Controller
    spi_slave u_spi_slave (
        .csb    (csb),
        .clk    (clk),
        .sdi    (sdi),
        .sdo    (sdo),
        .addr   (internal_addr),
        .wr_en  (internal_wr_en),
        .wr_data(internal_wr_data),
        .rd_data(internal_rd_data)
    );

    // Instantiate Register Map
    spi_reg_map u_spi_reg_map (
        .clk    (clk),
        .addr   (internal_addr),
        .wr_en  (internal_wr_en),
        .wr_data(internal_wr_data),
        .rd_data(internal_rd_data)
    );

endmodule