vlib work
vlog spi_master.sv spi_top.v spi_slave.v spi_reg_map.v
vsim -voptargs=+acc work.spi_master
add wave *
run -all