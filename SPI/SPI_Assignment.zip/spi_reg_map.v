`timescale 1ns / 1ps

module spi_reg_map (
    input  wire        clk,
    input  wire [14:0] addr,
    input  wire        wr_en,
    input  wire [7:0]  wr_data,
    output wire [7:0]  rd_data
);

    reg [7:0] mem [0:32767];

    // Combinational read: Required to meet the half-cycle constraint
    assign rd_data = mem[addr];

    // Synchronous write
    always @(posedge clk) begin
        if (wr_en) begin
            mem[addr] <= wr_data;
        end
    end

endmodule