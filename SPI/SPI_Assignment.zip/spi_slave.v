`timescale 1ns / 1ps

module spi_slave (
    input  wire        csb,
    input  wire        clk,
    input  wire        sdi,
    output wire        sdo,

    output reg [14:0] addr,
    output reg         wr_en,
    output reg  [7:0]  wr_data,
    input  wire [7:0]  rd_data
);

    localparam HEADER = 1'b0;
    localparam DATA   = 1'b1;

    reg        state;
    reg [3:0]  bit_cnt;   
    reg        rw_reg;    // 0 = Write, 1 = Read
    reg [6:0]  data_reg;

    reg        sdo_en;
    reg        sdo_reg;

    assign sdo  = (sdo_en) ? sdo_reg : 1'bz; // Tri-state Buffer

    // FSM and Write Logic (Positive Edge)
    always @(posedge clk or posedge csb) begin
        if (csb) begin
            state    <= HEADER;
            bit_cnt  <= 0;
            rw_reg   <= 0;
            addr <= 0;
            data_reg <= 0;
            wr_en    <= 0;
            wr_data  <= 0;
        end else begin
            case (state)
                HEADER: begin
                    wr_en <= 0; 
                    if (bit_cnt == 0) begin
                        rw_reg  <= sdi;
                        bit_cnt <= bit_cnt + 1;
                    end else begin
                        addr <= {addr[13:0], sdi};
                        bit_cnt  <= bit_cnt + 1;
                        state    <= (bit_cnt == 15) ? DATA : HEADER;
                    end
                end

                DATA: begin
                    data_reg <= {data_reg[5:0], sdi};

                    bit_cnt <= (bit_cnt < 7) ? bit_cnt + 1 : 0;

                    // Trigger write enable for one cycle when a full byte is ready
                    if (!rw_reg && bit_cnt == 7) begin
                        wr_en   <= 1;
                        wr_data <= {data_reg, sdi};
                    end else begin
                        wr_en   <= 0;
                    end

                    // Burst Auto-Increment
                    if (rw_reg) begin
                        if (bit_cnt == 7) addr <= addr + 1;
                    end else begin
                        if (wr_en) addr <= addr + 1;
                    end
                end
            endcase
        end
    end

    // Output Read Logic (Negative Edge for Half-Cycle Turnaround)
    always @(negedge clk or posedge csb) begin
        if (csb) begin
            sdo_en  <= 0;
            sdo_reg <= 0;
        end else if (state == DATA && rw_reg ) begin
            sdo_en <= 1;
            case (bit_cnt)
                0: sdo_reg <= rd_data[7];
                1: sdo_reg <= rd_data[6];
                2: sdo_reg <= rd_data[5];
                3: sdo_reg <= rd_data[4];
                4: sdo_reg <= rd_data[3];
                5: sdo_reg <= rd_data[2];
                6: sdo_reg <= rd_data[1];
                7: sdo_reg <= rd_data[0];
                default: sdo_reg <= 0;
            endcase
        end else begin
            sdo_en <= 0;
        end
    end

endmodule