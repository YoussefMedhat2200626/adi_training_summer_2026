`timescale 1ns / 1ps

module spi_master;

    // Timing Parameters
    localparam T_LEAD = 20; // Delay from CSB falling edge to first SCLK rising edge
    localparam T_LAG  = 20; // Delay from last SCLK falling edge to CSB rising edge
    
    logic clk;
    logic sclk_en;
    logic sclk;
    logic csb;
    logic sdi;
    logic sdo;

    // Top Instantiation
    spi_wrapper u_spi_wrapper (
        .csb(csb),
        .clk(sclk), 
        .sdi(sdi),
        .sdo(sdo)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk; 
    end

    // Gated SCLK
    assign sclk = (sclk_en) ? clk : 1'b0;

    // Tasks
    
    // Single Write Task
    task automatic single_write(input logic [14:0] addr, input logic [7:0] data);
        logic [15:0] header = {1'b0, addr}; // R/W bit = 0 for write
        
        @(posedge clk);
        csb = 0;
        sdi = header[15]; // Set first bit of header for the first clock edge
        #(T_LEAD);
        sclk_en = 1;
        
        // Shift Header Out
        for (int i = 14; i >= 0; i--) begin
            @(negedge clk);
            sdi = header[i];
        end
        
        // Shift Data Out
        for (int i = 7; i >= 0; i--) begin
            @(negedge clk);
            sdi = data[i];
        end
        
        repeat(2)@(negedge clk); // the salve need 2 more pos edges: one for the last data bit and one for the writing operation
    
        sclk_en = 0;
        #(T_LAG);
        csb = 1;
    endtask

    // Single Read Task with checker
    task automatic single_read(input logic [14:0] addr, input logic [7:0] expected_data);
        logic [15:0] header = {1'b1, addr}; // R/W bit = 1 for read
        logic [7:0]  rcv_data;
        
        @(posedge clk);
        csb = 0;
        sdi = header[15];
        #(T_LEAD);
        sclk_en = 1;
        
        // Shift Header Out
        for (int i = 14; i >= 0; i--) begin
            @(negedge clk);
            sdi = header[i];
        end
        @(negedge clk);

        // Capture Data
        for (int i = 7; i >= 0; i--) begin
            @(posedge clk);
            rcv_data[i] = sdo;
        end
        
        sclk_en = 0;
        #(T_LAG);
        csb = 1;
        
        // Checker
        if (rcv_data !== expected_data) begin
            $display("[SINGLE READ FAIL] Addr: %0h | Expected: %0h, Got: %0h", addr, expected_data, rcv_data);
        end else begin
            $display("[SINGLE READ PASS] Addr: %0h | Read: %0h", addr, rcv_data);
        end
    endtask

    // Burst Write Task
    task automatic burst_write(input logic [14:0] addr, input int num_bytes, input logic [7:0] start_data);
        logic [15:0] header = {1'b0, addr};
        logic [7:0]  current_data = start_data;
        
        @(posedge clk);
        csb = 0;
        sdi = header[15];
        #(T_LEAD);
        sclk_en = 1;
        
        // Shift Header Out
        for (int i = 14; i >= 0; i--) begin
            @(negedge clk);
            sdi = header[i];
        end
        
        // Shift Burst Data
        for (int byte_idx = 0; byte_idx < num_bytes; byte_idx++) begin
            for (int i = 7; i >= 0; i--) begin
                @(negedge clk);
                sdi = current_data[i];
            end
            current_data = current_data + 8'd4; // Increment data payload by 4 for each byte
                                                // to mimic changing data pattern
        end
        
        repeat(2)@(negedge clk);
        sclk_en = 0;
        #(T_LAG);
        csb = 1;
    endtask

    // Burst Read Task
    task automatic burst_read(input logic [14:0] addr, input int num_bytes, input logic [7:0] expected_start_data);
        logic [15:0] header = {1'b1, addr};
        logic [7:0]  current_expected = expected_start_data;
        logic [7:0]  rcv_data;
        
        @(posedge clk);
        csb = 0;
        sdi = header[15];
        #(T_LEAD);
        sclk_en = 1;
        
        // Shift Header Out
        for (int i = 14; i >= 0; i--) begin
            @(negedge clk);
            sdi = header[i];
        end
        @(negedge clk);
        
        // Capture Burst Data
        for (int byte_idx = 0; byte_idx < num_bytes; byte_idx++) begin
            for (int i = 7; i >= 0; i--) begin
                @(posedge clk);
                rcv_data[i] = sdo;
            end

            // Checker
            if (rcv_data !== current_expected) begin
                $display("[BURST READ FAIL] Addr Offset: +%0d | Expected: %0h, Got: %0h", byte_idx, current_expected, rcv_data);
            end else begin
                $display("[BURST READ PASS] Addr Offset: +%0d | Read: %0h", byte_idx, rcv_data);
            end
            
            current_expected = current_expected + 8'd4;
        end
        
        sclk_en = 0;
        #(T_LAG);
        csb = 1;
    endtask

    // Test Sequence
    initial begin
        // Initialization
        csb = 0;
        sclk_en = 0;
        @(posedge clk);
        csb = 1;
        
        repeat(3) @(posedge clk);
        
        // Test Case 1
        $display("Test Case 1: 4 Single Writes");
        single_write(15'h0A00, 8'hA0);
        single_write(15'h0B12, 8'hB1);
        single_write(15'h0C34, 8'hC2);
        single_write(15'h0D56, 8'hD3);
        
        // Test Case 2
        $display("Test Case 2: 4 Single Reads");
        single_read(15'h0A00, 8'hA0);
        single_read(15'h0B12, 8'hB1);
        single_read(15'h0C34, 8'hC2);
        single_read(15'h0D56, 8'hD3);
        
        // Test Case 3
        $display("Test Case 3: Burst Write (3 bytes)");
        burst_write(15'h0100, 3, 8'h20);
        
        // Test Case 4
        $display("Test Case 4: Burst Read (3 bytes)");
        burst_read(15'h0100, 3, 8'h20);
        
        $stop;
    end

endmodule