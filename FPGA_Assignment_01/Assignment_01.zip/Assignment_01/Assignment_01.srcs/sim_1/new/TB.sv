`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08/02/2026 12:57:16 AM
// Design Name: 
// Module Name: TB
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module TB();
    localparam second = 1_000_000_000;
    logic clk,rst_n;
    logic [2:0] counter;    
    Top count_inst (.clk(clk),.rst_n(rst_n),.counter(counter));
    initial begin
        clk=0;
        forever #5 clk = ~clk;
    end
    
    task delay (int x);
        repeat(x) begin
            #second;
        end
    endtask
    
    initial begin
        rst_n=0;
        delay(5);
        rst_n=1;
        delay(20);
        rst_n=0;
        delay(5);
        rst_n=1;       
        delay(25);
         $finish;
    end
endmodule
