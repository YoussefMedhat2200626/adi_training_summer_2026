`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08/02/2026 01:00:16 PM
// Design Name: 
// Module Name: Top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module Top(
    input clk,
    input rst_n,
    output [2:0] counter
    );
    
    wire clk_8MHz, clk_1Hz;
    wire rst_from_pll;
    
      clk_wiz_0 U_pll
     (
      // Clock out ports
      .clk_out1(clk_8MHz),     // output clk_out1
      // Status and control signals
      .resetn(rst_n), // input resetn
      .locked(rst_from_pll),       // output locked
     // Clock in ports
      .clk_in1(clk));      // input clk_in1
      
      DIV div_inst
      (
      .clk_in(clk_8MHz),
      .rst_n(rst_from_pll),
      .clk_out(clk_1Hz)
      );
      
      counter count_inst 
      (
      .clk(clk_1Hz),
      .rst_n(rst_from_pll),
      .counter(counter)
      );

endmodule
