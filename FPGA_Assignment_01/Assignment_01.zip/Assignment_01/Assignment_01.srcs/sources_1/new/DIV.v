`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08/02/2026 03:25:08 PM
// Design Name: 
// Module Name: DIV
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module DIV(
    input clk_in,
    input rst_n,
    output reg clk_out
    );
    reg [22:0] counter;
    always @(posedge clk_in or negedge rst_n)begin
        if(!rst_n)begin
            counter <= 23'd0;
            clk_out <= 1'b0;
        end
        else if(counter == 23'd3999999 )begin
            counter <= 0;
            clk_out <= ~clk_out;
        end
        else
            counter <= counter + 23'd1;
    end    
endmodule
